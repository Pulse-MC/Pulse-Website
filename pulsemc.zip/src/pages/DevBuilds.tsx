import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Download, GitCommit, User, Calendar, ChevronLeft, AlertCircle } from 'lucide-react';
import Button from '../components/global/Button';
import Card from '../components/global/Card';
import { BASE_URL } from '@/config/apiconfig';

interface DevBuild {
  version: string;
  build_id: number;
  commit_hash: string;
  author: string;
  commit_message: string;
  platform: string;
  upload_timestamp: string;
}

export default function DevBuilds() {
  const { version, build_number } = useParams<{ version?: string; build_number?: string }>();
  const navigate = useNavigate();
  const [builds, setBuilds] = useState<DevBuild[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedVersion, setSelectedVersion] = useState<string>(version || '');

  useEffect(() => {
    const fetchBuilds = async () => {
      setLoading(true);
      setError(null);
      try {
        let url = `${BASE_URL}/devbuilds`;
        const params = new URLSearchParams();

        if (version) params.append('version', version);
        if (build_number) params.append('build_id', build_number);

        if (params.toString()) {
          url += `?${params.toString()}`;
        }

        const response = await fetch(url);

        if (!response.ok) {
          throw new Error(`Failed to fetch dev builds: ${response.statusText}`);
        }

        const data = await response.json();
        setBuilds(Array.isArray(data.data) ? data.data : [data.data]);
      } catch (err) {
        console.error('Error fetching dev builds:', err);
        setError(err instanceof Error ? err.message : 'Failed to load dev builds');
        setBuilds([]);
      } finally {
        setLoading(false);
      }
    };

    fetchBuilds();
  }, [version, build_number]);

  const availableVersions = Array.from(new Set(builds.map(b => b.version))).sort().reverse();

  const filteredBuilds = selectedVersion
    ? builds.filter(b => b.version === selectedVersion)
    : builds;

  const handleVersionFilter = (ver: string) => {
    setSelectedVersion(ver);
    if (ver) {
      navigate(`/download/${ver}`);
    } else {
      navigate('/devbuilds');
    }
  };

  return (
    <div className="min-h-screen bg-black text-white">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-gray-400 hover:text-[#ff2929] transition-colors mb-6"
          >
            <ChevronLeft size={20} />
            Back to Home
          </Link>

          <h1 className="text-5xl md:text-6xl font-bold mb-4 font-syne">
            Dev <span className="text-[#ff2929]">Builds</span>
          </h1>
          <p className="text-xl text-gray-400 max-w-3xl">
            Latest development builds of Pulse. These builds contain cutting-edge features but may be unstable.
          </p>
        </motion.div>

        {availableVersions.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mb-8"
          >
            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => handleVersionFilter('')}
                className={`px-4 py-2 rounded-lg font-semibold transition-all ${
                  !selectedVersion
                    ? 'bg-[#ff2929] text-white'
                    : 'bg-white/5 text-gray-400 hover:bg-white/10'
                }`}
              >
                All Versions
              </button>
              {availableVersions.map((ver) => (
                <button
                  key={ver}
                  onClick={() => handleVersionFilter(ver)}
                  className={`px-4 py-2 rounded-lg font-semibold transition-all ${
                    selectedVersion === ver
                      ? 'bg-[#ff2929] text-white'
                      : 'bg-white/5 text-gray-400 hover:bg-white/10'
                  }`}
                >
                  {ver}
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {loading && (
          <div className="flex items-center justify-center py-20">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
              className="w-12 h-12 border-4 border-[#ff2929]/20 border-t-[#ff2929] rounded-full"
            />
          </div>
        )}

        {error && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-red-500/10 border border-red-500/30 rounded-xl p-6 mb-8"
          >
            <div className="flex items-center gap-3">
              <AlertCircle className="text-red-500" size={24} />
              <div>
                <h3 className="text-lg font-bold text-red-500">Error Loading Builds</h3>
                <p className="text-gray-400">{error}</p>
              </div>
            </div>
          </motion.div>
        )}

        {!loading && !error && filteredBuilds.length === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-20"
          >
            <h3 className="text-2xl font-bold text-gray-400 mb-2">No Dev Builds Found</h3>
            <p className="text-gray-500">
              {selectedVersion
                ? `No builds available for version ${selectedVersion}`
                : 'Check back later for new development builds'}
            </p>
          </motion.div>
        )}

        <div className="grid gap-4">
          {filteredBuilds.map((build, index) => (
            <motion.div
              key={`${build.version}-${build.build_id}`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <Card className="p-6" glowOnHover>
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <h3 className="text-2xl font-bold text-white">
                        DevBuild #{build.build_id} [Pulse-{build.platform}]
                      </h3>
                      <span className="px-3 py-1 bg-[#ff2929]/20 text-[#ff2929] rounded-full text-sm font-semibold">
                        {build.version}
                      </span>
                    </div>

                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2 text-gray-400">
                        <GitCommit size={16} />
                        <span className="font-mono">{build.commit_hash.substring(0, 8)}</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-400">
                        <User size={16} />
                        <span>{build.author}</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-400">
                        <Calendar size={16} />
                        <span>{new Date(build.upload_timestamp).toLocaleDateString()}</span>
                      </div>
                    </div>

                    <p className="mt-4 text-gray-300 leading-relaxed">
                      {build.commit_message}
                    </p>
                  </div>

                  <div className="flex-shrink-0">
                    <Button
                      onClick={() => window.open(`${BASE_URL}/devbuild/download/${build.build_id}`, '_blank')}
                      variant="primary"
                      size="large"
                      icon={Download}
                    >
                      Download
                    </Button>
                  </div>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
